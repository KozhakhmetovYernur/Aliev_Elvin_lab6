# Трассировка UC-01
| Правило / исключение | Функция | Исключение | API | Тест |
|---|---|---|---|---|
| БП-01 Согласие | create_draft | ConsentRequired | 403 | test_consent_required |
| БП-02 Данные клиента | search_client, create_draft | InvalidClient | 400 | test_invalid_client |
| БП-03 Сумма и срок | validate_terms, checked_quote | TermsOutOfRange | 422 | test_amount_boundaries, test_term_boundaries |
| БП-04 Доход | set_income | RequiredField / NegativeIncome | 400 / 422 | test_income_required_and_negative |
| БП-05 Платёж | annuity_payment | ValueError (прямой вызов), ProductError (API quotes) | 400 / 422 | исходные PaymentTests и test_payment_rejects_bad_direct_input |
| БП-06 Только черновик редактируется | ensure_draft | InvalidState | 409 | test_submitted_edit_forbidden |
| БП-07 Роль и владелец | ensure_specialist, get_application | AccessDenied | 403 | test_role_and_owner |
| БП-08 Версия заявки | ensure_draft | VersionConflict | 409 | test_version_conflict |
| БП-09 Обработка ошибок | api_errors | CreditError | http_status | test_api_error_and_state |
| БП-10 Повтор без дубля | submit | InvalidState при ином ключе | 200 / 409 | test_repeat_submission |
| БП-11 Фиксация статуса и времени | submit | — | 200 | test_main_flow |
| 1а Клиент не найден | search_client | — | 200 items=[] | test_search_empty_and_found |
| 2а Неверная анкета | create_draft, ClientForm | InvalidClient / ошибка формата | 400 | test_invalid_client, test_format_and_anonymous_api |
| 4а Условия вне диапазона | checked_quote | TermsOutOfRange | 422 | test_api_error_and_state |
| 6а Нет поля / отрицательный доход | set_income | RequiredField / NegativeIncome | 400 / 422 | test_income_required_and_negative |
| 8а Продукт выключен | checked_quote | ProductChanged | 409 | test_changed_product |
| 8б Неизвестен итог подачи | submit + detail_api | повтор с тем же ключом | 200, тот же ID | test_repeat_submission, test_api_main_flow |

Ключ уникален в БД. При конкурентном конфликте СУБД возможен IntegrityError; нагрузочное конкурентное выполнение не входит в проведённый прогон. Участки сохранения обёрнуты transaction.atomic(), записи выбираются select_for_update(); PostgreSQL поддерживает блокировки строк, SQLite локально — другой режим блокировок.
