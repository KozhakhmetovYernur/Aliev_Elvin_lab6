# API UC-01 после ЛР7
Авторизация: Django session. Запись требует CSRF. Сотрудник состоит в credit_specialist и читает только свои заявки.
GET /api/products/ ->200 {items}; POST /api/quotes/ {product_id,amount,months}->200 расчёт. Сохранены из ЛР6.
POST /api/clients/search/ {iin}->200 {items:[{client_id,fio}]}; пустой список при отсутствии; 400 INVALID_CLIENT.
POST /api/applications/drafts/ {client:{iin,fio,birth_date,phone},consent_ref}->201 {id,state:DRAFT,version:1}; 400 INVALID_JSON/INVALID_CLIENT; 403 CONSENT_REQUIRED.
PATCH /api/applications/{id}/terms/ {product_id,amount,months,expected_version}->200 {id,state,version,monthly_payment,...}; 422 TERMS_OUT_OF_RANGE; 409 PRODUCT_CHANGED/VERSION_CONFLICT/INVALID_STATE.
PATCH /api/applications/{id}/income/ {income,employment,expected_version}->200 {id,state,version,...}; 400 REQUIRED_FIELD/INVALID_JSON; 422 NEGATIVE_INCOME; 409 VERSION_CONFLICT/INVALID_STATE.
POST /api/applications/{id}/submit/ {expected_version}; Idempotency-Key ->200 {id,state:SUBMITTED,version,submitted_at}; повтор с прежним ключом ->200 с прежним ID/версией/временем; 409 при ином ключе после подачи. Отсутствует ключ ->400 INVALID_CLIENT.
GET /api/applications/{id}/ ->200 состояние; 401 AUTH_REQUIRED, 403 FORBIDDEN, 404 NOT_FOUND.
Изменение ЛР6: коды INVALID_STATE, NOT_FOUND, FORBIDDEN уточнены для реализации. Отсутствие CSRF даёт 403 фреймворка. Сетевой тайм-аут не трактуется как отказ; повтор и чтение состояния идут по ID. Идемпотентность черновика пока не реализована, повтор создания не входит в текущий тест полного потока.
