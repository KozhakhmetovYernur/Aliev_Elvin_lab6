# Журнал дефектов
| ID | Симптом | Тип | Как найдена | Причина и исправление | Коммит |
|---|---|---|---|---|---|
| D-01 | NaN возвращается как платёж; нулевой срок вызывает DivisionByZero | Времени выполнения | test_payment_rejects_bad_direct_input, initial-tests.txt | Добавлены проверки конечности, знака и положительного целого срока | 949f53a fix: reject invalid arguments in public payment calculation |
| D-02 | Минимум 100000 отклоняется | Логическая, контролируемая мутация | test_amount_boundaries, D-02-mutation.txt; остановка pdb на БП-03 | Временно <= заменено на < у нижней границы; граничный тест упал; <= восстановлено | См. git log, fix: restore inclusive lower amount boundary |
| D-03 | Максимум 5000000 отклоняется | Логическая, контролируемая мутация | test_amount_boundaries, D-03-mutation.txt | Временно <= заменено на < у верхней границы; тест упал; <= восстановлено | См. git log, fix: restore inclusive upper amount boundary |

D-02 и D-03 — учебные мутации по условию задания 5. Все три исправлены. Обнаруженная линтером потеря импорта InvalidOperation также устранена перед итоговым запуском.
