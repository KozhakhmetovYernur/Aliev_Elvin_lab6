from django.db import models


class Client(models.Model):
    iin = models.CharField("ИИН", max_length=12, unique=True)
    fio = models.CharField("ФИО", max_length=150)
    birth_date = models.DateField("Дата рождения")
    phone = models.CharField("Телефон", max_length=20)

    class Meta:
        verbose_name = "Клиент"
        verbose_name_plural = "Клиенты"

    def __str__(self):
        return f"{self.fio} ({self.iin})"
