# КредитЗаявка — лабораторная работа 7
Алиев Эльвин · 25-19. Оформление потребительского кредита в банке.

## Установка и запуск
Python 3.12. Из папки credit-bank:
```
python -m venv .venv
```
Windows: `.venv\Scripts\activate`; Linux/macOS: `source .venv/bin/activate`.
```
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py loaddata demo
python manage.py create_demo_user
python manage.py runserver
```
Вход http://127.0.0.1:8000/login/ — demo / demo-bank7. Это локальный учебный пользователь; перед внешним развёртыванием смените пароль и настройки безопасности.
Шесть экранов: /applications/new/ → /applications/{id}/terms/ → income/ → review/ → result/; список /applications/.
Каталог / и /api/products/; расчёт POST /api/quotes/. Полный API: docs/api-contract.md.
Админка /admin/: модели зарегистрированы. Для редактирования создайте своего администратора `python manage.py createsuperuser`.

## Проверка
```
python manage.py test
python -m ruff check .
python -m coverage run --branch --source=catalog.services,lending.services manage.py test
python -m coverage report
```
coverage: установите отдельно `python -m pip install coverage==7.17.2`.
11 исходных и 18 новых тестов. Новые даты вычисляются относительно timezone.localdate().
Модели в accounts, catalog, lending; правила в services; ввод в forms; HTTP и страницы в views; доступ к каталогу в repositories.

## Документы
Трассировка docs/traceability.md; дефекты docs/defects.md; исходный ADR docs/adr/ADR-001-stack.md. Ветка feature/uc-01 слита в main локально. Адрес, ранее предоставленный автором: https://github.com/KozhakhmetovYernur/Aliev_Elvin_lab6. Изменения этой лабораторной на GitHub не отправлялись.

## Границы версии
Заявка проходит от анкеты до состояния «Подана». Реальные БКИ, решение о выдаче, договор, подпись и перечисление денег не подключены. Данные синтетические. Повтор подачи с тем же ключом проверен последовательно; конкуренция нескольких процессов и повтор создания черновика требуют отдельных тестов.
