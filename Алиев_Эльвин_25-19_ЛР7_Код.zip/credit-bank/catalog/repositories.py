"""Слой доступа к данным: ORM вместо заглушки ЛР6."""

from .models import Product


def list_products():
    return [
        {
            "id": p.code,
            "name": p.name,
            "min_amount": str(p.min_amount),
            "max_amount": str(p.max_amount),
            "min_months": p.min_months,
            "max_months": p.max_months,
            "annual_rate": str(p.annual_rate),
            "active": p.active,
        }
        for p in Product.objects.order_by("id")
    ]
