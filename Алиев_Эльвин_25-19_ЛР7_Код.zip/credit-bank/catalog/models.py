from django.db import models


class Product(models.Model):
    code = models.CharField("Код версии", max_length=60, unique=True)
    name = models.CharField("Название", max_length=100)
    min_amount = models.DecimalField("Минимальная сумма", max_digits=12, decimal_places=2)
    max_amount = models.DecimalField("Максимальная сумма", max_digits=12, decimal_places=2)
    min_months = models.PositiveIntegerField("Минимальный срок")
    max_months = models.PositiveIntegerField("Максимальный срок")
    annual_rate = models.DecimalField("Годовая ставка", max_digits=5, decimal_places=2)
    active = models.BooleanField("Действует", default=True)

    class Meta:
        verbose_name = "Кредитный продукт"
        verbose_name_plural = "Кредитные продукты"
        constraints = [
            models.CheckConstraint(
                condition=models.Q(min_amount__lte=models.F("max_amount")),
                name="product_amount_bounds",
            ),
            models.CheckConstraint(
                condition=models.Q(min_months__lte=models.F("max_months")),
                name="product_term_bounds",
            ),
        ]

    def __str__(self):
        return f"{self.name} / {self.code}"
