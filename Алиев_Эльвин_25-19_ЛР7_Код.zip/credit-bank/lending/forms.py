from django import forms


class ClientForm(forms.Form):
    iin = forms.RegexField(
        r"^[0-9]{12}$",
        label="ИИН",
        max_length=12,
        error_messages={"invalid": "ИИН должен содержать 12 цифр"},
    )
    fio = forms.CharField(label="ФИО", max_length=150)
    birth_date = forms.DateField(
        label="Дата рождения", widget=forms.DateInput(attrs={"type": "date"})
    )
    phone = forms.RegexField(
        r"^\+7[0-9]{10}$",
        label="Телефон",
        max_length=12,
        error_messages={"invalid": "Введите +7 и 10 цифр"},
    )
    consent_ref = forms.CharField(label="Номер согласия", max_length=80, required=False)


class TermsForm(forms.Form):
    product_id = forms.CharField(label="Код продукта", max_length=60)
    amount = forms.DecimalField(label="Сумма, ₸", max_digits=12, decimal_places=2)
    months = forms.IntegerField(label="Срок, месяцев")
    expected_version = forms.IntegerField(widget=forms.HiddenInput)


class IncomeForm(forms.Form):
    income = forms.DecimalField(
        label="Ежемесячный доход, ₸", max_digits=12, decimal_places=2, required=False
    )
    employment = forms.ChoiceField(
        label="Занятость",
        required=False,
        choices=[
            ("", "Выберите"),
            ("employed", "Работаю по найму"),
            ("self_employed", "Самозанятый"),
            ("other", "Другое"),
        ],
    )
    expected_version = forms.IntegerField(widget=forms.HiddenInput)
