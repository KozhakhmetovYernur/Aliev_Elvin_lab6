from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Создать локального учебного сотрудника"

    def handle(self, *args, **options):
        user, _ = get_user_model().objects.get_or_create(
            username="demo", defaults={"is_staff": True}
        )
        user.set_password("demo-bank7")
        user.save()
        group, _ = Group.objects.get_or_create(name="credit_specialist")
        user.groups.add(group)
        self.stdout.write("Учебный вход: demo / demo-bank7")
