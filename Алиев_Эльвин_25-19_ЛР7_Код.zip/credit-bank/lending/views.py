import json
from functools import wraps
from uuid import uuid4

from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.csrf import ensure_csrf_cookie
from django.views.decorators.http import require_http_methods, require_POST

from catalog.services import ProductError

from . import forms, services
from .errors import CreditError
from .services import product_options, quote


@require_POST
def quote_api(request):
    try:
        data = json.loads(request.body)
        if not isinstance(data, dict):
            raise ValueError("JSON object required")
        result = quote(data["product_id"], data["amount"], data["months"])
        return JsonResponse(result)
    except (KeyError, TypeError, ValueError) as error:
        if isinstance(error, ProductError):
            return JsonResponse(
                {"error": error.code, "message": error.message}, status=error.status
            )
        return JsonResponse(
            {"error": "INVALID_JSON", "message": "Проверьте JSON и поля"}, status=400
        )


@ensure_csrf_cookie
def product_screen(request):
    return render(request, "lending/products.html", {"products": product_options()})


def product_api(request):
    return JsonResponse({"items": product_options()}, json_dumps_params={"ensure_ascii": False})


def payload(app):
    return {
        "id": app.pk,
        "state": app.state,
        "version": app.version,
        "client": app.client.fio,
        "amount": str(app.amount),
        "months": app.months,
        "submitted_at": app.submitted_at.isoformat() if app.submitted_at else None,
    }


def api_errors(function):
    @wraps(function)
    def wrapped(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return JsonResponse({"error": "AUTH_REQUIRED"}, status=401)
        try:
            return function(request, *args, **kwargs)
        except CreditError as error:
            return JsonResponse(
                {"error": error.code, "message": error.message}, status=error.http_status
            )
        except (ValueError, KeyError, TypeError):
            return JsonResponse(
                {"error": "INVALID_JSON", "message": "Проверьте поля запроса"}, status=400
            )

    return wrapped


def json_data(request):
    value = json.loads(request.body)
    if not isinstance(value, dict):
        raise ValueError()
    return value


def validated(form):
    if not form.is_valid():
        raise ValueError()
    return form.cleaned_data


@require_POST
@api_errors
def search_api(request):
    clients = services.search_client(json_data(request)["iin"], request.user)
    return JsonResponse({"items": [{"client_id": c.pk, "fio": c.fio} for c in clients]})


@require_POST
@api_errors
def draft_api(request):
    raw = json_data(request)
    data = validated(forms.ClientForm({**raw["client"], "consent_ref": raw.get("consent_ref", "")}))
    consent = data.pop("consent_ref")
    return JsonResponse(payload(services.create_draft(data, consent, request.user)), status=201)


@require_http_methods(["PATCH"])
@api_errors
def terms_api(request, pk):
    data = validated(forms.TermsForm(json_data(request)))
    app = services.set_terms(
        pk,
        data["product_id"],
        data["amount"],
        data["months"],
        data["expected_version"],
        request.user,
    )
    result = payload(app)
    result.update(services.quote(app.product.code, app.amount, app.months))
    return JsonResponse(result)


@require_http_methods(["PATCH"])
@api_errors
def income_api(request, pk):
    data = validated(forms.IncomeForm(json_data(request)))
    return JsonResponse(
        payload(
            services.set_income(
                pk, data["income"], data["employment"], data["expected_version"], request.user
            )
        )
    )


@require_POST
@api_errors
def submit_api(request, pk):
    data = json_data(request)
    version = data["expected_version"]
    if type(version) is not int:
        raise ValueError()
    return JsonResponse(
        payload(
            services.submit(pk, version, request.headers.get("Idempotency-Key", ""), request.user)
        )
    )


@require_http_methods(["GET"])
@api_errors
def detail_api(request, pk):
    return JsonResponse(payload(services.get_application(pk, request.user)))


@login_required
def new_screen(request):
    form = forms.ClientForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        data = form.cleaned_data.copy()
        consent = data.pop("consent_ref")
        try:
            app = services.create_draft(data, consent, request.user)
            return redirect("terms", pk=app.pk)
        except CreditError as error:
            form.add_error(None, error.message)
    return render(
        request,
        "lending/form.html",
        {"form": form, "title": "Э-01 Анкета клиента", "button": "Далее", "back": "/"},
    )


@login_required
def terms_screen(request, pk):
    app = services.get_application(pk, request.user)
    form = forms.TermsForm(
        request.POST or None,
        initial={
            "product_id": app.product.code if app.product_id else "cash-standard-v1",
            "amount": app.amount,
            "months": app.months,
            "expected_version": app.version,
        },
    )
    if request.method == "POST" and form.is_valid():
        d = form.cleaned_data
        try:
            services.set_terms(
                pk, d["product_id"], d["amount"], d["months"], d["expected_version"], request.user
            )
            return redirect("income", pk=pk)
        except CreditError as error:
            form.add_error(None, error.message)
    return render(
        request,
        "lending/form.html",
        {
            "form": form,
            "title": "Э-02 Условия кредита",
            "button": "Далее",
            "products": services.product_options(),
            "back": "/applications/new/",
        },
    )


@login_required
def income_screen(request, pk):
    app = services.get_application(pk, request.user)
    form = forms.IncomeForm(
        request.POST or None,
        initial={
            "income": app.income,
            "employment": app.employment,
            "expected_version": app.version,
        },
    )
    if request.method == "POST" and form.is_valid():
        d = form.cleaned_data
        try:
            services.set_income(
                pk, d["income"], d["employment"], d["expected_version"], request.user
            )
            return redirect("review", pk=pk)
        except CreditError as error:
            form.add_error(None, error.message)
    return render(
        request,
        "lending/form.html",
        {
            "form": form,
            "title": "Э-03 Доход и занятость",
            "button": "Проверить заявку",
            "back": f"/applications/{pk}/terms/",
        },
    )


@login_required
def review_screen(request, pk):
    app = services.get_application(pk, request.user)
    key = request.POST.get("key") or str(uuid4())
    error = ""
    if request.method == "POST":
        try:
            services.submit(pk, int(request.POST["expected_version"]), key, request.user)
            return redirect("result", pk=pk)
        except CreditError as e:
            error = e.message
    return render(request, "lending/review.html", {"app": app, "key": key, "error": error})


@login_required
def result_screen(request, pk):
    return render(
        request, "lending/result.html", {"app": services.get_application(pk, request.user)}
    )


@login_required
def applications_screen(request):
    services.ensure_specialist(request.user)
    from .models import Application

    return render(
        request,
        "lending/list.html",
        {
            "items": Application.objects.filter(owner=request.user)
            .select_related("client")
            .order_by("-id")
        },
    )
