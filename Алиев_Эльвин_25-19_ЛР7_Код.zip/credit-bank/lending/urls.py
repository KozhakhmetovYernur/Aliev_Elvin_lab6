from django.urls import path

from . import views

urlpatterns = [
    path("", views.product_screen, name="products"),
    path("api/products/", views.product_api),
    path("api/quotes/", views.quote_api),
    path("api/clients/search/", views.search_api),
    path("api/applications/drafts/", views.draft_api),
    path("api/applications/<int:pk>/terms/", views.terms_api),
    path("api/applications/<int:pk>/income/", views.income_api),
    path("api/applications/<int:pk>/submit/", views.submit_api),
    path("api/applications/<int:pk>/", views.detail_api),
    path("applications/new/", views.new_screen, name="new"),
    path("applications/<int:pk>/terms/", views.terms_screen, name="terms"),
    path("applications/<int:pk>/income/", views.income_screen, name="income"),
    path("applications/<int:pk>/review/", views.review_screen, name="review"),
    path("applications/<int:pk>/result/", views.result_screen, name="result"),
    path("applications/", views.applications_screen, name="applications"),
]
