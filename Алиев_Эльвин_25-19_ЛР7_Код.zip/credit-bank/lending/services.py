from decimal import ROUND_HALF_UP, Decimal, InvalidOperation, localcontext

from django.db import transaction
from django.utils import timezone

from accounts.models import Client
from catalog.models import Product
from catalog.services import ProductError, validate_terms
from catalog.services import list_products as catalog_products

from .errors import (
    AccessDenied,
    ConsentRequired,
    InvalidClient,
    InvalidState,
    NegativeIncome,
    NotFound,
    ProductChanged,
    RequiredField,
    TermsOutOfRange,
    VersionConflict,
)
from .models import Application

"""Слой логики: БП-05, аннуитетный предварительный платёж."""


def annuity_payment(amount, months, annual_rate):
    """Шаг 4 UC-01: предварительный аннуитетный платёж по БП-05."""
    try:
        principal, annual = Decimal(str(amount)), Decimal(str(annual_rate))
    except InvalidOperation as error:
        raise ValueError("Неверный формат суммы или ставки") from error
    if not principal.is_finite() or principal <= 0:
        raise ValueError("Сумма должна быть положительной и конечной")
    if not annual.is_finite() or annual < 0:
        raise ValueError("Ставка должна быть неотрицательной и конечной")
    if type(months) is not int or months <= 0:
        raise ValueError("Срок должен быть положительным целым")
    with localcontext() as context:
        context.prec = 36
        rate = annual / 1200
        if rate == 0:
            payment = principal / months
        else:
            payment = principal * rate / (1 - (1 + rate) ** (-months))
        return payment.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def quote(product_id, amount, months):
    """Шаги 3–4 UC-01: проверить условия и рассчитать платёж."""
    product, amount, months = validate_terms(product_id, amount, months)
    payment = annuity_payment(amount, months, product["annual_rate"])
    return {
        "product_id": product_id,
        "amount": str(amount.quantize(Decimal("0.01"))),
        "months": months,
        "annual_rate": product["annual_rate"],
        "monthly_payment": str(payment),
        "currency": "KZT",
        "preliminary": True,
    }


def product_options():
    """Получить варианты для экрана Э-02 через слой логики каталога."""
    return catalog_products()


MIN_INCOME = Decimal("0")  # БП-04: доход неотрицательный.
SPECIALIST = "credit_specialist"  # БП-07: оформление выполняет кредитный специалист.


def ensure_specialist(user):
    """Шаг 1 UC-01: проверить роль сотрудника, БП-07."""
    if not user.is_authenticated or not user.groups.filter(name=SPECIALIST).exists():
        raise AccessDenied()


def search_client(iin, user):
    """Шаг 1 UC-01: найти клиента; отсутствие совпадений — пустой список, 1а."""
    ensure_specialist(user)
    if not isinstance(iin, str) or len(iin) != 12 or not iin.isascii() or not iin.isdigit():
        raise InvalidClient()
    return list(Client.objects.filter(iin=iin))


@transaction.atomic
def create_draft(data, consent_ref, user):
    """Шаги 1–2 UC-01: согласие, клиент и черновик; БП-01, БП-02."""
    ensure_specialist(user)
    if not consent_ref.strip():
        raise ConsentRequired()
    if (
        not data["iin"].isascii()
        or not data["iin"].isdigit()
        or len(data["iin"]) != 12
        or not data["fio"].strip()
        or data["birth_date"] > timezone.localdate()
    ):
        raise InvalidClient()
    client, _ = Client.objects.get_or_create(iin=data["iin"], defaults=data)
    return Application.objects.create(client=client, owner=user, consent_ref=consent_ref)


def get_application(pk, user, lock=False):
    """Шаги 2–8 UC-01: чтение своей заявки; БП-07."""
    ensure_specialist(user)
    query = Application.objects.select_related("client", "product")
    if lock:
        query = query.select_for_update()
    app = query.filter(pk=pk).first()
    if app is None:
        raise NotFound()
    if app.owner_id != user.pk:
        raise AccessDenied()
    return app


def ensure_draft(app, version):
    """Шаги 3–7 UC-01: защита от изменения поданной заявки и потери версии."""
    if app.state != Application.State.DRAFT:
        raise InvalidState()
    if app.version != version:
        raise VersionConflict()


def checked_quote(code, amount, months):
    """Шаг 4 UC-01: согласовать коды исключений с контрактом ЛР6, 4а/8а."""
    try:
        return quote(code, amount, months)
    except ProductError as error:
        if error.code == "PRODUCT_NOT_FOUND":
            raise ProductChanged() from error
        if error.status == 422:
            raise TermsOutOfRange() from error
        raise InvalidClient() from error


@transaction.atomic
def set_terms(pk, code, amount, months, version, user):
    """Шаги 3–4 UC-01: продукт, сумма, срок и предварительный платёж; БП-03/05."""
    app = get_application(pk, user, lock=True)
    ensure_draft(app, version)
    checked_quote(code, amount, months)
    app.product = Product.objects.get(code=code)
    app.amount, app.months = amount, months
    app.version += 1
    app.save(update_fields=["product", "amount", "months", "version"])
    return app


@transaction.atomic
def set_income(pk, income, employment, version, user):
    """Шаги 5–6 UC-01: обязательность и неотрицательность дохода; БП-04, 6а."""
    app = get_application(pk, user, lock=True)
    ensure_draft(app, version)
    if income is None or not employment:
        raise RequiredField()
    if not income.is_finite() or income < MIN_INCOME:
        raise NegativeIncome()
    app.income, app.employment = income, employment
    app.version += 1
    app.save(update_fields=["income", "employment", "version"])
    return app


@transaction.atomic
def submit(pk, version, key, user):
    """Шаги 7–8 UC-01: повторная проверка и подача без дубля; БП-06/08/10/11."""
    app = get_application(pk, user, lock=True)
    if app.state == Application.State.SUBMITTED and app.operation_key == key:
        return app
    ensure_draft(app, version)
    if not key or len(key) > 80:
        raise InvalidClient()
    if not app.consent_ref:
        raise ConsentRequired()
    if app.product_id is None:
        raise RequiredField()
    checked_quote(app.product.code, app.amount, app.months)
    if app.income is None or not app.employment:
        raise RequiredField()
    if app.income < MIN_INCOME:
        raise NegativeIncome()
    if Application.objects.filter(operation_key=key).exclude(pk=pk).exists():
        raise VersionConflict()
    app.state, app.operation_key = Application.State.SUBMITTED, key
    app.submitted_at = timezone.now()
    app.version += 1
    app.save(update_fields=["state", "operation_key", "submitted_at", "version"])
    return app
