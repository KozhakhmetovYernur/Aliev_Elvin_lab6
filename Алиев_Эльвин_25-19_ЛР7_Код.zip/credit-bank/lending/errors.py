class CreditError(ValueError):
    http_status = 422
    message = "Не удалось выполнить операцию"
    code = "CREDIT_ERROR"


class InvalidClient(CreditError):
    http_status, code, message = 400, "INVALID_CLIENT", "Проверьте данные клиента"


class ConsentRequired(CreditError):
    http_status, code, message = 403, "CONSENT_REQUIRED", "Укажите номер согласия клиента"


class AccessDenied(CreditError):
    http_status, code, message = 403, "FORBIDDEN", "Недостаточно прав"


class NotFound(CreditError):
    http_status, code, message = 404, "NOT_FOUND", "Заявка не найдена"


class VersionConflict(CreditError):
    http_status, code, message = 409, "VERSION_CONFLICT", "Заявка изменена. Обновите страницу"


class InvalidState(CreditError):
    http_status, code, message = 409, "INVALID_STATE", "Заявка уже подана"


class ProductChanged(CreditError):
    http_status, code, message = (
        409,
        "PRODUCT_CHANGED",
        "Условия продукта изменились. Выберите продукт снова",
    )


class RequiredField(CreditError):
    http_status, code, message = 400, "REQUIRED_FIELD", "Заполните доход и занятость"


class NegativeIncome(CreditError):
    http_status, code, message = 422, "NEGATIVE_INCOME", "Доход не может быть отрицательным"


class TermsOutOfRange(CreditError):
    http_status, code, message = (
        422,
        "TERMS_OUT_OF_RANGE",
        "Сумма или срок выходят за границы продукта",
    )
