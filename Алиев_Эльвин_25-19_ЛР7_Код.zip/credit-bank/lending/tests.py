import json
from decimal import Decimal

from django.test import TestCase

from catalog.services import ProductError, validate_terms
from lending.services import annuity_payment, quote


class PaymentTests(TestCase):
    fixtures = ["demo"]

    def test_zero_rate(self):
        self.assertEqual(annuity_payment("120000", 12, "0"), Decimal("10000.00"))

    def test_annuity_known_result(self):
        self.assertEqual(annuity_payment("1000000", 12, "24"), Decimal("94559.60"))

    def test_inclusive_bounds(self):
        self.assertEqual(quote("cash-standard-v1", "100000", 6)["months"], 6)
        validate_terms("cash-standard-v1", "5000000", 60)

    def test_amount_out_of_range(self):
        with self.assertRaises(ProductError) as context:
            quote("cash-standard-v1", "99999.99", 6)
        self.assertEqual(context.exception.code, "AMOUNT_OUT_OF_RANGE")

    def test_invalid_values(self):
        for value in ["NaN", "Infinity", "abc", True, "100000.001"]:
            with self.subTest(value=value), self.assertRaises(ProductError):
                quote("cash-standard-v1", value, 6)

    def test_fractional_term_rejected(self):
        with self.assertRaises(ProductError):
            quote("cash-standard-v1", "100000", 6.5)


class HttpTests(TestCase):
    fixtures = ["demo"]

    def test_screen_and_api_same_catalog(self):
        page = self.client.get("/")
        self.assertIn("csrftoken", page.cookies)
        api = self.client.get("/api/products/")
        self.assertEqual(api.status_code, 200)
        for item in api.json()["items"]:
            self.assertContains(page, item["name"])
            self.assertContains(page, item["annual_rate"])

    def test_quote_api(self):
        response = self.client.post(
            "/api/quotes/",
            data=json.dumps({"product_id": "cash-standard-v1", "amount": "1000000", "months": 12}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["monthly_payment"], "94559.60")

    def test_quote_error(self):
        response = self.client.post(
            "/api/quotes/",
            data=json.dumps({"product_id": "cash-standard-v1", "amount": "1", "months": 12}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 422)
        self.assertEqual(response.json()["error"], "AMOUNT_OUT_OF_RANGE")

    def test_invalid_json(self):
        response = self.client.post("/api/quotes/", data="[", content_type="application/json")
        self.assertEqual(response.status_code, 400)

    def test_csrf_required(self):
        from django.test import Client

        response = Client(enforce_csrf_checks=True).post(
            "/api/quotes/", data="{}", content_type="application/json"
        )
        self.assertEqual(response.status_code, 403)
