"""Регрессия UC-01 и бизнес-правил оформления кредита."""

import json
from datetime import timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.db import IntegrityError, transaction
from django.test import TestCase
from django.utils import timezone

from accounts.models import Client
from catalog.models import Product
from catalog.services import ProductError, validate_terms

from . import errors, services
from .models import Application


class WorkflowTests(TestCase):
    fixtures = ["demo"]

    def setUp(self):
        self.user = get_user_model().objects.create_user("tester", password="test-password")
        group, _ = Group.objects.get_or_create(name="credit_specialist")
        self.user.groups.add(group)
        self.client.force_login(self.user)
        self.data = {
            "iin": "000000000003",
            "fio": "Тестовый Клиент Три",
            "birth_date": timezone.localdate() - timedelta(days=25 * 365),
            "phone": "+77000000003",
        }

    def draft(self):
        return services.create_draft(self.data, "CONSENT-DEMO", self.user)

    def ready(self):
        app = self.draft()
        app = services.set_terms(
            app.pk, "cash-standard-v1", Decimal("100000"), 6, app.version, self.user
        )
        return services.set_income(app.pk, Decimal("200000"), "employed", app.version, self.user)

    def test_main_flow(self):
        """Шаги 1–8 UC-01: клиент, черновик, условия, доход и подача."""
        app = self.ready()
        result = services.submit(app.pk, app.version, "op-1", self.user)
        self.assertEqual(result.state, "SUBMITTED")
        self.assertIsNotNone(result.submitted_at)
        self.assertEqual(result.client.iin, self.data["iin"])

    def test_search_empty_and_found(self):
        """1а: отсутствие совпадения — пустой список; существующий клиент найден."""
        self.assertEqual(services.search_client("000000009999", self.user), [])
        self.assertEqual(len(services.search_client("000000000001", self.user)), 1)

    def test_invalid_client(self):
        """2а: неверная анкета и дата рождения в будущем отклоняются."""
        for value in ["short", "１２３４５６７８９０１２", "12345678901A"]:
            with self.subTest(value=value), self.assertRaises(errors.InvalidClient):
                services.search_client(value, self.user)
        data = {**self.data, "birth_date": timezone.localdate() + timedelta(days=1)}
        with self.assertRaises(errors.InvalidClient):
            services.create_draft(data, "C", self.user)

    def test_consent_required(self):
        """БП-01: без согласия черновик не создаётся."""
        with self.assertRaises(errors.ConsentRequired):
            services.create_draft(self.data, "", self.user)
        self.assertEqual(Application.objects.count(), 0)

    def test_amount_boundaries(self):
        """БП-03, 4а: минимум/максимум включены; соседние копейки запрещены."""
        for amount in ["100000", "5000000"]:
            with self.subTest(amount=amount):
                self.assertEqual(services.quote("cash-standard-v1", amount, 12)["currency"], "KZT")
        for amount in ["99999.99", "5000000.01"]:
            with self.subTest(amount=amount), self.assertRaises(errors.TermsOutOfRange):
                services.checked_quote("cash-standard-v1", amount, 12)

    def test_term_boundaries(self):
        """БП-03, 4а: 6 и 60 месяцев разрешены, 5 и 61 запрещены."""
        for months in [6, 60]:
            with self.subTest(months=months):
                validate_terms("cash-standard-v1", "100000", months)
        for months in [5, 61]:
            with self.subTest(months=months), self.assertRaises(ProductError):
                validate_terms("cash-standard-v1", "100000", months)

    def test_income_required_and_negative(self):
        """6а и БП-04: обязательное поле; доход -0.01 отклоняется, нулевой принимается."""
        app = self.draft()
        with self.assertRaises(errors.RequiredField):
            services.set_income(app.pk, None, "", app.version, self.user)
        with self.assertRaises(errors.NegativeIncome):
            services.set_income(app.pk, Decimal("-0.01"), "employed", app.version, self.user)
        self.assertEqual(
            services.set_income(app.pk, Decimal("0"), "employed", app.version, self.user).income, 0
        )

    def test_changed_product(self):
        """8а: продукт выключен до подачи; заявка остаётся черновиком."""
        app = self.ready()
        Product.objects.filter(pk=app.product_id).update(active=False)
        with self.assertRaises(errors.ProductChanged):
            services.submit(app.pk, app.version, "op-1", self.user)
        app.refresh_from_db()
        self.assertEqual(app.state, "DRAFT")

    def test_repeat_submission(self):
        """8б и БП-10: повтор с прежним ключом возвращает ту же подачу."""
        app = self.ready()
        first = services.submit(app.pk, app.version, "op-1", self.user)
        second = services.submit(app.pk, app.version, "op-1", self.user)
        self.assertEqual(first.pk, second.pk)
        self.assertEqual(first.submitted_at, second.submitted_at)
        self.assertEqual(first.version, second.version)

    def test_submitted_edit_forbidden(self):
        """БП-06: после подачи условия не редактируются."""
        app = self.ready()
        app = services.submit(app.pk, app.version, "op-1", self.user)
        with self.assertRaises(errors.InvalidState):
            services.set_terms(
                app.pk, "cash-standard-v1", Decimal("200000"), 12, app.version, self.user
            )

    def test_version_conflict(self):
        """БП-08: устаревшая версия не перезаписывает заявку."""
        app = self.ready()
        with self.assertRaises(errors.VersionConflict):
            services.set_income(app.pk, Decimal("300000"), "employed", 1, self.user)

    def test_role_and_owner(self):
        """БП-07: нет роли или заявка принадлежит другому сотруднику — 403."""
        other = get_user_model().objects.create_user("other")
        with self.assertRaises(errors.AccessDenied):
            services.create_draft(self.data, "C", other)
        app = self.draft()
        other.groups.add(Group.objects.get(name="credit_specialist"))
        with self.assertRaises(errors.AccessDenied):
            services.get_application(app.pk, other)
        with self.assertRaises(errors.NotFound):
            services.get_application(999, self.user)

    def test_api_error_and_state(self):
        """4а: PATCH возвращает 422 и не сохраняет недопустимую сумму."""
        app = self.draft()
        response = self.client.patch(
            f"/api/applications/{app.pk}/terms/",
            json.dumps(
                {
                    "product_id": "cash-standard-v1",
                    "amount": "99999.99",
                    "months": 12,
                    "expected_version": app.version,
                }
            ),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 422)
        self.assertEqual(response.json()["error"], "TERMS_OUT_OF_RANGE")
        app.refresh_from_db()
        self.assertIsNone(app.amount)

    def test_api_main_flow(self):
        """API шагов 1–8: POST, PATCH, PATCH, POST и GET используют одну заявку."""
        body = {
            "client": {**self.data, "birth_date": self.data["birth_date"].isoformat()},
            "consent_ref": "C",
        }
        response = self.client.post(
            "/api/applications/drafts/", json.dumps(body), content_type="application/json"
        )
        self.assertEqual(response.status_code, 201)
        pk = response.json()["id"]
        response = self.client.patch(
            f"/api/applications/{pk}/terms/",
            json.dumps(
                {
                    "product_id": "cash-standard-v1",
                    "amount": "100000",
                    "months": 6,
                    "expected_version": 1,
                }
            ),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        response = self.client.patch(
            f"/api/applications/{pk}/income/",
            json.dumps({"income": "200000", "employment": "employed", "expected_version": 2}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        response = self.client.post(
            f"/api/applications/{pk}/submit/",
            json.dumps({"expected_version": 3}),
            content_type="application/json",
            HTTP_IDEMPOTENCY_KEY="api-op-1",
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.client.get(f"/api/applications/{pk}/").json()["state"], "SUBMITTED")

    def test_screen_flow_and_business_error(self):
        """Э-01–Э-06: переходы экранов; текст исключения 6а виден на Э-03."""
        self.assertContains(self.client.get("/applications/new/"), "Э-01")
        body = {**self.data, "birth_date": self.data["birth_date"].isoformat(), "consent_ref": "C"}
        self.assertEqual(self.client.post("/applications/new/", body).status_code, 302)
        app = Application.objects.get()
        self.assertContains(self.client.get(f"/applications/{app.pk}/terms/"), "Э-02")
        self.client.post(
            f"/applications/{app.pk}/terms/",
            {
                "product_id": "cash-standard-v1",
                "amount": "100000",
                "months": 6,
                "expected_version": 1,
            },
        )
        response = self.client.post(
            f"/applications/{app.pk}/income/",
            {"income": "-1", "employment": "employed", "expected_version": 2},
        )
        self.assertContains(response, "Доход не может быть отрицательным")
        self.client.post(
            f"/applications/{app.pk}/income/",
            {"income": "200000", "employment": "employed", "expected_version": 2},
        )
        self.assertContains(self.client.get(f"/applications/{app.pk}/review/"), "Э-04")
        self.client.post(
            f"/applications/{app.pk}/review/", {"expected_version": 3, "key": "web-op"}
        )
        self.assertContains(self.client.get(f"/applications/{app.pk}/result/"), "Подана")
        self.assertContains(self.client.get("/applications/"), "Э-06")

    def test_format_and_anonymous_api(self):
        """2а: неверный формат — 400; без входа — 401."""
        response = self.client.post(
            "/api/applications/drafts/", "{}", content_type="application/json"
        )
        self.assertEqual(response.status_code, 400)
        self.client.logout()
        self.assertEqual(self.client.get("/api/applications/1/").status_code, 401)

    def test_integrity(self):
        """Т-3: ИИН уникален; повторный клиент не создаётся."""
        with transaction.atomic(), self.assertRaises(IntegrityError):
            Client.objects.create(
                iin="000000000001",
                fio="Повтор",
                birth_date=timezone.localdate(),
                phone="+77000000000",
            )

    def test_payment_rejects_bad_direct_input(self):
        """D-01: неверные аргументы публичного расчёта отклоняются до формулы."""
        for amount, months, rate in [
            ("NaN", 12, 24),
            ("100000", 0, 24),
            ("-1", 12, 24),
            ("100000", 12, -1),
        ]:
            with self.subTest(amount=amount, months=months), self.assertRaises(ValueError):
                services.annuity_payment(amount, months, rate)
