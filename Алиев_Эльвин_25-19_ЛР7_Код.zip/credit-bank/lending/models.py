from django.conf import settings
from django.db import models


class Application(models.Model):
    class State(models.TextChoices):
        DRAFT = "DRAFT", "Черновик"
        SUBMITTED = "SUBMITTED", "Подана"

    client = models.ForeignKey("accounts.Client", on_delete=models.PROTECT, verbose_name="Клиент")
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, verbose_name="Сотрудник"
    )
    product = models.ForeignKey(
        "catalog.Product", on_delete=models.PROTECT, null=True, verbose_name="Кредитный продукт"
    )
    amount = models.DecimalField("Сумма", max_digits=12, decimal_places=2, null=True)
    months = models.PositiveIntegerField("Срок в месяцах", null=True)
    income = models.DecimalField("Ежемесячный доход", max_digits=12, decimal_places=2, null=True)
    employment = models.CharField("Занятость", max_length=30, blank=True)
    consent_ref = models.CharField("Номер согласия", max_length=80)
    state = models.CharField("Статус", max_length=20, choices=State.choices, default=State.DRAFT)
    version = models.PositiveIntegerField("Версия", default=1)
    operation_key = models.CharField(
        "Ключ подачи", max_length=80, null=True, blank=True, unique=True
    )
    created_at = models.DateTimeField("Создана", auto_now_add=True)
    submitted_at = models.DateTimeField("Подана", null=True, blank=True)

    class Meta:
        verbose_name = "Кредитная заявка"
        verbose_name_plural = "Кредитные заявки"

    def __str__(self):
        return f"Заявка №{self.pk} — {self.get_state_display()}"
