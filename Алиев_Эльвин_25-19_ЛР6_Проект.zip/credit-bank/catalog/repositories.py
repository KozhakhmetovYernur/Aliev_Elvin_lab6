"""Доступ к данным: заглушка каталога, заменяемая на ORM в ЛР №7."""

from copy import deepcopy

_PRODUCTS = [
    {
        "id": "cash-standard-v1",
        "name": "Потребительский стандарт",
        "min_amount": "100000.00",
        "max_amount": "5000000.00",
        "min_months": 6,
        "max_months": 60,
        "annual_rate": "24.00",
        "active": True,
    },
    {
        "id": "cash-short-v1",
        "name": "Короткий срок",
        "min_amount": "50000.00",
        "max_amount": "1000000.00",
        "min_months": 3,
        "max_months": 24,
        "annual_rate": "20.00",
        "active": True,
    },
    {
        "id": "cash-fixed-v1",
        "name": "Фиксированный платёж",
        "min_amount": "300000.00",
        "max_amount": "3000000.00",
        "min_months": 12,
        "max_months": 48,
        "annual_rate": "22.00",
        "active": True,
    },
]


def list_products():
    return deepcopy(_PRODUCTS)
