"""Логика каталога: БП-03, границы суммы и срока."""

from decimal import Decimal, InvalidOperation

from . import repositories


class ProductError(ValueError):
    def __init__(self, code, message, status=422):
        self.code, self.message, self.status = code, message, status
        super().__init__(message)


def list_products():
    return [item for item in repositories.list_products() if item["active"]]


def validate_terms(product_id, amount, months):
    product = next((p for p in list_products() if p["id"] == product_id), None)
    if product is None:
        raise ProductError("PRODUCT_NOT_FOUND", "Продукт не найден или недоступен", 404)
    if isinstance(amount, bool) or len(str(amount)) > 30:
        raise ProductError("INVALID_AMOUNT", "Некорректная сумма", 400)
    try:
        amount = Decimal(str(amount))
    except (InvalidOperation, ValueError, TypeError) as error:
        raise ProductError("INVALID_AMOUNT", "Некорректная сумма", 400) from error
    if not amount.is_finite() or amount.as_tuple().exponent < -2:
        raise ProductError("INVALID_AMOUNT", "Сумма должна иметь не более 2 знаков", 400)
    if type(months) is not int:
        raise ProductError("INVALID_TERM", "Срок должен быть целым числом месяцев", 400)
    if not Decimal(product["min_amount"]) <= amount <= Decimal(product["max_amount"]):
        raise ProductError("AMOUNT_OUT_OF_RANGE", "Сумма выходит за границы продукта")
    if not product["min_months"] <= months <= product["max_months"]:
        raise ProductError("TERM_OUT_OF_RANGE", "Срок выходит за границы продукта")
    return product, amount, months
