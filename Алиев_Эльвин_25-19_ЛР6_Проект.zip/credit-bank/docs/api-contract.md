# Контракт API UC-01
Проектные операции (ЛР №7): POST /api/clients/search/, POST /api/applications/drafts/,
PATCH /api/applications/{id}/terms/, PATCH /api/applications/{id}/income/,
POST /api/applications/{id}/submit/, GET /api/applications/{id}/.
2а: 400 INVALID_CLIENT. 4а: 422 TERMS_OUT_OF_RANGE.
6а: 400 REQUIRED_FIELD / 422 NEGATIVE_INCOME.
8а: 409 PRODUCT_CHANGED. 8б: сеть/504 шлюза; проверить GET по ID,
затем повторить подачу с тем же Idempotency-Key при состоянии DRAFT.
Доступ к этим операциям ещё не реализован.

Реализованы:
GET /api/products/ -> 200 {items: [...]}, тот же каталог, что на Э-02.
POST /api/quotes/ с product_id, amount (строка), months (целое)
-> 200 {monthly_payment, currency, preliminary, ...}.
Ошибки: 400 INVALID_JSON/INVALID_AMOUNT/INVALID_TERM,
404 PRODUCT_NOT_FOUND, 422 AMOUNT_OUT_OF_RANGE/TERM_OUT_OF_RANGE.
Для браузерного POST с сессией требуется CSRF-токен; без него 403.
Полный формат запросов и ответов изложен в отчёте ЛР №6.
