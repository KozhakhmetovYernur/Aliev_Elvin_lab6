"""Слой логики: БП-05, аннуитетный предварительный платёж."""

from decimal import ROUND_HALF_UP, Decimal, localcontext

from catalog.services import list_products as catalog_products
from catalog.services import validate_terms


def annuity_payment(amount, months, annual_rate):
    with localcontext() as context:
        context.prec = 36
        principal, rate = Decimal(str(amount)), Decimal(str(annual_rate)) / 1200
        if rate == 0:
            payment = principal / months
        else:
            payment = principal * rate / (1 - (1 + rate) ** (-months))
        return payment.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def quote(product_id, amount, months):
    product, amount, months = validate_terms(product_id, amount, months)
    payment = annuity_payment(amount, months, product["annual_rate"])
    return {
        "product_id": product_id,
        "amount": str(amount.quantize(Decimal("0.01"))),
        "months": months,
        "annual_rate": product["annual_rate"],
        "monthly_payment": str(payment),
        "currency": "KZT",
        "preliminary": True,
    }


def product_options():
    """Получить варианты для экрана Э-02 через слой логики каталога."""
    return catalog_products()
