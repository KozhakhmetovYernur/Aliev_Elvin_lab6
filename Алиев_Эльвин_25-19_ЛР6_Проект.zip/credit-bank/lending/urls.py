from django.urls import path

from . import views

urlpatterns = [
    path("", views.product_screen, name="products"),
    path("api/products/", views.product_api, name="product-api"),
    path("api/quotes/", views.quote_api, name="quote-api"),
]
