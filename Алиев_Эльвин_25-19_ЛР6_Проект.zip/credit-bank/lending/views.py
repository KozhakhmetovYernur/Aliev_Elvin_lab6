import json

from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import ensure_csrf_cookie
from django.views.decorators.http import require_POST

from catalog.services import ProductError

from .services import product_options, quote


@require_POST
def quote_api(request):
    try:
        data = json.loads(request.body)
        if not isinstance(data, dict):
            raise ValueError("JSON object required")
        result = quote(data["product_id"], data["amount"], data["months"])
        return JsonResponse(result)
    except (KeyError, TypeError, ValueError) as error:
        if isinstance(error, ProductError):
            return JsonResponse(
                {"error": error.code, "message": error.message}, status=error.status
            )
        return JsonResponse(
            {"error": "INVALID_JSON", "message": "Проверьте JSON и поля"}, status=400
        )


@ensure_csrf_cookie
def product_screen(request):
    return render(request, "lending/products.html", {"products": product_options()})


def product_api(request):
    return JsonResponse({"items": product_options()}, json_dumps_params={"ensure_ascii": False})
