"""Будущая точка проверки согласий и прав. Пользовательские данные не хранятся."""

ROLES = ("credit_specialist", "decision_officer", "administrator")
